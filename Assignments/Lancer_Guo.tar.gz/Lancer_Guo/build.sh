#!/bin/bash

# Build the compiler

make clean -C ./src
make -C ./src